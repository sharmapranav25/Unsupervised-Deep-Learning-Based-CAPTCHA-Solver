<?php

declare(strict_types=1);
/**
 * @link http://www.yiiframework.com/
 *
 * @copyright Copyright (c) 2008 Yii Software LLC
 * @license http://www.yiiframework.com/license/
 */

namespace Yiisoft\Yii\Captcha;

/**
 * VerifyCodeGeneratorTrait provides configurable implementation for [[DriverInterface::generateVerifyCode()]].
 * This trait should be used at the class, which implements [[DriverInterface]].
 */
trait VerifyCodeGeneratorTrait
{
    /**
     * @var int the minimum length for randomly generated word. Defaults to 6.
     */
    public $minLength = 6;
    /**
     * @var int the maximum length for randomly generated word. Defaults to 7.
     */
    public $maxLength = 7;

    /**
     * Generates new CAPTCHA code.
     *
     * @throws \Exception if it was not possible to gather sufficient entropy.
     *
     * @return string CAPTCHA code.
     */
    public function generateVerifyCode(): string
    {
        if ($this->minLength > $this->maxLength) {
            $this->maxLength = $this->minLength;
        }
        if ($this->minLength < 3) {
            $this->minLength = 3;
        }
        if ($this->maxLength > 20) {
            $this->maxLength = 20;
        }
        $length = random_int($this->minLength, $this->maxLength);

        $letters = 'bcdfghjklmnpqrstvwxyz';
        $vowels = 'aeiou';
        $code = '';
        for ($i = 0; $i < $length; ++$i) {
            if (($i % 2 && random_int(0, 10) > 2) || (!($i % 2) && random_int(0, 10) > 9)) {
                $code .= $vowels[random_int(0, 4)];
            } else {
                $code .= $letters[random_int(0, 20)];
            }
        }

        return $code;
    }
}
