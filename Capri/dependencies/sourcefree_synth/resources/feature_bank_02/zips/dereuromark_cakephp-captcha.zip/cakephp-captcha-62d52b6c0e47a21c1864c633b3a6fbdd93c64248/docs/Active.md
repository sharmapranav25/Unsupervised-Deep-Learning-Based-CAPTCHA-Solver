## Active Captchas

By default, the plugin provides an unobtrusive math captcha as images.
Simple math captchas are also usually a bit more fun than trying to figure out some unreadable words behind colorful bars.
But since this plugin ships with a highly extensible interface solution, you can write and use your own captcha image solution.

There is for example a built in NullEngine to also build hidden ones (mainly leveraging the min/max time).

### Forms with tables
You can add the behavior to your model inside the specific action: or you can simply
```php
$this->MyTable->addBehavior('Captcha.Captcha');
```

You can also use the component (and the optional actions array) to auto-add the behavior to your model:
```php
// inside initialize() of controller
$this->loadComponent('Captcha.Captcha');
```
The component has the advantage that it also auto-loads the Captcha helper for your template forms.
Otherwise you need to manually load it.

If you only want to validate captchas for certain actions, the component can be white-listed to certain actions:
```php
$this->loadComponent('Captcha.Captcha', [
    'actions' => ['add', 'edit'],
]);
```

Now load the helper, e.g in your AppView:
```php
$this->loadHelper('Captcha.Captcha');
```

Add a captcha control in your form:
```php
echo $this->Captcha->render(['placeholder' => __('Please solve the riddle')]);
```

That's it, it should now display the images to solve.
The helper stores the active challenge UUID in a hidden `captcha_uuid` field and uses that UUID in the image URL instead of exposing the internal numeric database id.

`render()` by default adds both active and passive form elements.
You can use `control()` to only use active ones.
The passive element is only a low-assurance honeypot and should be treated as supplemental filtering, not as the main protection layer.

### Working with model-less forms
E.g. for a contact form, first add this in your controller's `initialize()`:
```php
$this->loadComponent('Captcha.Captcha');
```

Then inside your action, use `addValidation()` to inject the plugin's validation rules into the form validator:
```php
use Tools\Form\ContactForm; // or any other form

$contactForm = new ContactForm();

if ($this->request->is('post')) {
    $this->Captcha->addValidation($contactForm->getValidator());

    if ($contactForm->execute($this->request->getData())) {
        // Send email and redirect
    }
    // Display validation errors
}
```

Also here, don't forget to add the helper call.

### Configuration

You can configure it globally using Configure class - and `app.php`:
```
'Captcha' => [
    'engine' => ...,
    'mathType => ...,
    'imageType => ...,
    'complexity' => ...,
    ...
],
```

If you configure it locally, make sure you set it to the same for both Component and Behavior.

### Exchanging the MathEngine `mathType`

If the `SimpleMath` addition/substraction does not cut it for you, you can simply hook in your won class.
```php
namespace App\Engine\Math;

use Captcha\Engine\Math\MathInterface;

class ComplexMath implements MathInterface {

    /**
     * @return string
     */
    public function getExpression(): string {
        ...
    }

    /**
     * @return string
     */
    public function getValue(): string {
        ...
    }

}
```

### NullEngine
The Null engine with its hidden form input can be used for either more passive captchas (hidden from user),
or just to validate min/max time.
This mode is also low-assurance and is only suitable where basic nuisance filtering is sufficient.
```php
use Captcha\Engine\NullEngine;

    ...
    'Captcha' => [
        'engine' => NullEngine::class,
        'minTime' => 6, // seconds
```

### Use your own Captcha engine

You can also completely switch the engine by using the `engine` Configure key:
```
'engine' => 'App\Engine\WordEngine'
```

The engine could look like:
```php
namespace App\Engine;

use Captcha\Engine\EngineInterface;

class WordEngine implements EngineInterface {

    /**
     * @return array
     */
    public function generate(): array {
        ...
    }

    /**
     * @param \Cake\Validation\Validator $validator
     * @return void
     */
    public function buildValidator(Validator $validator): void {
        ...
    }

}
```

### Throttle and Garbage Collect
With such a DB driven tool you must clean out your table daily or even hourly based on the traffic.
Use the `maxTime` config to define the time span a captcha is valid, and when it can be removed as outdated.
The built in solution here is to auto-clean when creating images on a probability level (0...100). Default for `cleanupProbability` is `10` (percent).
You can also use a simple cron job that does it. Set `cleanupProbability` to `0` then.

The `minTime` is by default 2 seconds and make sure you cannot auto-post a form too fast.

One should also include a throttle limit, so you cannot fill up the DB.
The built in mechanism is a `maxPerUser` value (defaults to 100) which prevents entering more than this amount per ip or session.
If a form gets built too often, new captcha rows will stop being persisted temporarily once this limit is reached.
The user will be blocked at most for 1 hour, customizable with `deadlockMinutes` config parameter. The user may submit new forms earlier depending on client IP and session ID.
Note that this feature is primarily about limiting DB growth from issued challenges.

Separately, active captchas also include a verification-side rate limiter by default:

```php
'Captcha' => [
    'verifyRateLimit' => [
        'enabled' => true,
        'maxFailures' => 5,
        'window' => 600,
        'scope' => 'ip_session', // 'ip_session' or 'ip'
        'cache' => 'default',
    ],
],
```

This limiter applies to failed verification attempts, not challenge creation. It is enabled by default and is tracked via Cake Cache. The default policy counts wrong answers as well as invalid or already-used `captcha_uuid` submissions. Timing failures (`minTime`/`maxTime`) do not consume that budget.

The same verification policy applies to `NullEngine`. After the timing checks pass, its token
is consumed atomically and cannot be reused. `solved` remains `null`, since there was no riddle.
A successful verification clears previous failures, provided any attached honeypot checks pass too.

### Verification cache

Use a shared cache with atomic `add` and `increment` operations, such as Redis or Memcached,
for enforcement across concurrent requests and application workers. Set its duration to at least
`verifyRateLimit.window`. The default file-cache fallback uses a read/write counter and can lose
increments under concurrent load. Array cache is for tests; Null cache cannot enforce a limit.

The limiter uses fixed time buckets, so the budget resets at the next bucket boundary rather
than a full window after the latest failure. `ip_session` separates sessions at the same IP;
`ip` shares their budget and may also group unrelated users behind a shared address.

### Larger captcha images

When dealing with larger images, the default DB type `binary` will not work for sure.
For MySQL the type `blob` is used when detected as DB.
For other systems please use own migration then and set your preferred type that can hold enough information.
