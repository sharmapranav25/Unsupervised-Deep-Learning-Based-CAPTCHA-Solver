Yii2 Captcha Extended
=====================

[Yii2 Captcha Extended](https://github.com/lubosdz/yii2-captcha-extended) is an extension written for Yii2 framework.
It enhances original captcha code delivered along with the framework - see [DEMO](https://synet.sk/blog/php/260-yii-framework-demos).
Version for Yii 1.x is available at [Yii Framework Extensions](https://www.yiiframework.com/extension/captcha-extended).


Features
========

* supports modes: default, math, mathverbal, words, logical
* supports extended characters latin1, latin2 (utf-8) including middle- east- european and cyrillyc characters
* adds visual obfuscation elements: dots density, through lines, fillSections, random text & background color
* mode-dependent options: randomUpperLowerCase (default mode), resultMultiplier (math mode)

![Screenshot](http://static.synet.sk/captchaExtendedShot.png)
![Screenshot](http://static.synet.sk/captchaExtendedShot-sk.png)<br />
![Screenshot](http://static.synet.sk/captchaExtendedShot-de.png)
![Screenshot](http://static.synet.sk/captchaExtended-logical.gif)<br />
![Screenshot](http://static.synet.sk/captchaExtended-mathverbal.gif)<br />
![Screenshot](http://static.synet.sk/captchaExtended-math.gif)

INSTALLATION
============

1) Install via composer:

```bash
$ composer require "lubosdz/yii2-captcha-extended" : "~1.0.0"
```

or you can include the following in your composer.json file:

```json
{
	"require": {
		"lubosdz/yii2-captcha-extended" : "~1.0.0"
	}
}
```

2) Define action in controller, e.g. `SiteController`:

```php

public function actions()
{
	return [
		'captcha' => [
			'class' => 'lubosdz\captchaExtended\CaptchaExtendedAction',
			// optionally, set mode and obfuscation properties e.g.:
			'mode' => 'math',
			//'mode' => CaptchaExtendedAction::MODE_MATH,
			//'resultMultiplier' => 5,
			//'lines' => 5,
			//'density' => 10,
			//'height' => 50,
			//'width' => 150,
		],
	];
}

```

3) Define client validation in `LoginForm::rules()`:

```php

public $verifyCode;

public function rules()
{
	return [
		['verifyCode', 'lubosdz\captchaExtended\CaptchaExtendedValidator',
			'captchaAction' => Url::to('/site/captcha'),
		],
	];
}

```

4) In view defined captcha field inside login form e.g.:

```php

<?php $form = ActiveForm::begin() ?>

// ...

<?= $form->field($model, 'verifyCode')->widget(Captcha::className(), [
	'captchaAction' => Url::to('/site/captcha'),
	'template' => '<div class="text-center">{image}</div><br/> {input} ',
	'imageOptions' => [
		'class' => 'img-fluid',
		'style' => 'cursor:pointer; width: 100%',
		'title' => Yii::t('app', 'Click to refresh the code'),
	],
	'options' => [
		'placeholder' => Yii::t('app', 'Verification code'),
		'class' => 'form-control',
	],
])->label(false) ?>

// ...

<?php ActiveForm::end(); ?>

```

5) If needed, collect localized strings via CLI command `yiic message messages/config.php` and translate captcha related strings.

6) Since by default capchta configures to default framework's settings, you may want to adjust some options:

	* `mode` - default|math|mathverbal|logical|words,
		* for the `words` mode, you can replace your own file [words.txt] or [words.yourlanguage.txt]
	* `density` - dots density [0-100],
	* `lines` - the number of through lines [0-20],
	* `fillSections` - the number of fillSections [0-20],
	* `letters` - define your own first characters set (UTF-8 supported)
	* `vowels` - define your own second characters set (UTF-8 supported)
	* `resultMultiplier` - applied to math mode to increase formula difficulty
	* `fileWords` - abs. path to file with your own defined locale words (UTF-8 supported)
	* `randomUpperLowerCase` - mix up randomly upper & lower characters from characters sets
	* `paramRefreshUrl` - set your own URL refresh param, defaults to `v`
	* also note standard properties supported by framework: `width`, `height`, `padding`, `offset`, `foreColor`, `backColor`, `transparent`, `minLength`, `maxLength`, ..

7) Enjoy! :-)


Changelog
=========

Version 1.0.5 - Nov 7, 2023
------------------------------

- PHP 8.2+ compatability
- enable unicode in REGEX by default (/u modifier)


Version 1.0.4 - Jun 30, 2021
------------------------------

- updated SK, CS words (dropped accented characters)


Version 1.0.3 - Jun 07, 2020
------------------------------

- minor compatability fix for PHP 7.4+


Version 1.0.2 - Feb 25, 2020
------------------------------

- configurable refresh parameter in URL
- updated docs


Version 1.0.1 - May 21, 2018
------------------------------

- added CS (Czech) words file
- center formula horizontaly
- updated documentation


Version 1.0.0 - March 28, 2018
------------------------------

- rework of previous extension for Yii 1.x branch
- added new options - custom character sets, resultMultiplier, randomUpperLowerCase, Imagick support
- couple of potential bugfixes e.g. calculating pixel color ranges
- full multibyte (MB) support
- added support for installation via composer

