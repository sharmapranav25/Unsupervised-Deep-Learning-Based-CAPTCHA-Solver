<?php

/**
 * Options for the CAPTCHA plugin
 *
 * @author Andreas Gohr <andi@splitbrain.org>
 */

$meta['mode'] = array(
    'multichoice',
    '_choices' => array(
        'js',
        'text',
        'math',
        'question',
        'image',
        'audio',
        'svg',
        'svgaudio',
        'figlet',
    ),
);
$meta['forusers'] = array('onoff');
$meta['loginprotect'] = array('multichoice', '_choices' => array(0, 1, 2));
$meta['lettercount'] = array('numeric', '_min' => 3, '_max' => 16);
$meta['width'] = array('numeric', '_pattern' => '/[0-9]+/');
$meta['height'] = array('numeric', '_pattern' => '/[0-9]+/');
$meta['question'] = array('string');
$meta['answer'] = array('string');
$meta['logindenial'] = array('numeric', '_min' => 0, '_max' => 60);
$meta['logindenial_max'] = array('numeric', '_min' => 0, '_max' => 86400);
