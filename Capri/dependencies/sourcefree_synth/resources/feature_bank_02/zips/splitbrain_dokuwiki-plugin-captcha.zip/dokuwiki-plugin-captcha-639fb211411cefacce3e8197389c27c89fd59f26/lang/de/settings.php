<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Seb <test@example.com>
 * @author AloisT <tiefenbrunner@outlook.com>
 * @author Andreas Gohr <andi@splitbrain.org>
 * @author Thomas Templin <templin@gnuwhv.de>
 * @author Leo Rudin <leo.rudin@gmx.ch>
 * @author F. Mueller-Donath <j.felix@mueller-donath.de>
 */
$lang['mode']                  = 'Welcher CAPTCHA-Typ soll benutzt werden?';
$lang['mode_o_js']             = 'Text (automatisch ausgefüllt via JavaScript)';
$lang['mode_o_text']           = 'Text (manuell auszufüllen)';
$lang['mode_o_math']           = 'Mathe-Aufgabe';
$lang['mode_o_question']       = 'Feste Frage';
$lang['mode_o_image']          = 'Bild (nicht barrierefrei)';
$lang['mode_o_audio']          = 'Bild+Audio (barrierefrei)';
$lang['mode_o_svg']            = 'SVG (nicht barrierefrei, lesbar)';
$lang['mode_o_svgaudio']       = 'SVG + Audio (barrierefrei, lesbar)';
$lang['mode_o_figlet']         = 'Figlet ASCII-Kunst (nicht barrierefrei)';
$lang['forusers']              = 'Soll das CAPTCHA auch für eingeloggte Benutzer gebraucht werden?';
$lang['lettercount']           = 'Anzahl der zu verwendenen Buchstaben (3-16). Wenn Sie die Anzahl erhöhen, denken Sie daran auch die Breite des Bildes im nächsten Feld zu erhöhen.';
$lang['width']                 = 'Weite des CAPTCHA Bildes (pixel)';
$lang['height']                = 'Höhe des CAPTCHA Bildes (pixel)';
$lang['question']              = 'Frage für den "Feste Frage" Modus.';
$lang['answer']                = 'Antwort für den "Feste Frage" Modus.';
$lang['loginprotect']          = 'Benötigt es ein CAPTCHA um sich einzuloggen?';
$lang['loginprotect_o_0']      = 'Niemals';
$lang['loginprotect_o_1']      = 'Immer';
$lang['loginprotect_o_2']      = 'Nach 3 Fehlversuchen';
$lang['logindenial']           = 'Exponentielle Wartezeit für falsche Logins verwenden. Basiswartezeit in Sekunden (0 zum Deaktivieren, verdoppelt sich mit jeden Fehlversuch)';
$lang['logindenial_max']       = 'Maximale Wartezeit in Sekunden';
