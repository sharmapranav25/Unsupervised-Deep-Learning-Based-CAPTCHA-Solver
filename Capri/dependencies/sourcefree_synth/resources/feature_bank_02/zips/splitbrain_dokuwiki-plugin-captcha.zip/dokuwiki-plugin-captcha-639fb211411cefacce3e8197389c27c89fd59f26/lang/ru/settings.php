<?php

/**
 * @license    GPL 2 (http://www.gnu.org/licenses/gpl.html)
 *
 * @author Aleksandr Selivanov <alexgearbox@yandex.ru>
 * @author Iliya <iliyabylich04@gmail.com>
 * @author Yuriy Skalko <yuriy.skalko@gmail.com>
 * @author Ilya Rozhkov <impeck@ya.ru>
 * @author Shpak Andrey <ashpak@ashpak.ru>
 */
$lang['mode']                  = 'Какой тип CAPTCHA использовать?';
$lang['mode_o_js']             = 'Текст (заполнение JavaScript)';
$lang['mode_o_text']           = 'Текст (ручной ввод)';
$lang['mode_o_math']           = 'Математическая задача';
$lang['mode_o_question']       = 'Конкретный вопрос';
$lang['mode_o_image']          = 'Изображение (хорошая защита)';
$lang['mode_o_audio']          = 'Изображение и звук (плохая защита)';
$lang['mode_o_svg']            = 'SVG (плохая доступность, читаемый)';
$lang['mode_o_svgaudio']       = 'SVG+звук (лучшая доступность, читаемый)';
$lang['mode_o_figlet']         = 'Figlet ASCII Art (хорошая защита)';
$lang['forusers']              = 'Использовать CAPTCHA для зарегистрированных пользователей?';
$lang['lettercount']           = 'Количество букв (3-16). Если вы увеличиваете количество букв, не забудьте также увеличить ширину изображения ниже.';
$lang['width']                 = 'Ширина изображения CAPTCHA (пиксели)';
$lang['height']                = 'Высота изображения CAPTCHA (пиксели)';
$lang['question']              = 'Вопрос для режима конкретного вопроса';
$lang['answer']                = 'Ответ для режима конкретного вопроса ';
$lang['loginprotect']          = 'Требовать ввод CAPTCHA для входа?';
$lang['loginprotect_o_0']      = 'Ничего';
$lang['loginprotect_o_1']      = 'Всегда';
$lang['loginprotect_o_2']      = 'После 3-х неверных попыток';
$lang['logindenial']           = 'Использовать экспоненциальное время ожидания для неудачных попыток входа в систему. Базовое время ожидания в секундах (0 (ноль) для отключения; удваивается с каждой неудачей).';
$lang['logindenial_max']       = 'Макс. время ожидания в секундах';
